const CACHE='kyrenza-v2';
const ASSETS=['./','./index.html','./styles.css','./script.js','./manifest.webmanifest','./assets/kyrenza-mark.png','./assets/kyrenza-logo-transparent.png','./assets/hero-workspace.svg','./assets/service-collage.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
